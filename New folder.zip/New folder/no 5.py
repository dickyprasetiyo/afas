from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.log import setLogLevel
from mininet.cli import CLI
from mininet.nodelib import NAT
from mininet.util import irange
from subprocess import Popen, PIPE, STDOUT
import os
import time

class LinuxRouter( Node ) :
  def config(self, **params) :
      super( LinuxRouter, self).config( **params)
      self.cmd( "??") #IP forwarding
      self.cmd( "ip addr add ?? brd +dev r0-eth0")# IP address Class C /24 for r0-eth0
      self.cmd( "ip addr add ?? brd +dev r0-eth1")# IP address Class B /24 for r0-eth1
      self.cmd( "ip addr add ?? brd +dev r0-eth2")# IP address Class A /24 for r0-eth2
      self.cmd( "ip addr add ?? brd +dev r0-eth3")# IP address Class C /24 for r0-eth3

class NetworkTopo( Topo ):
    def build(self, **_opts):
        # Add router
        router = self.addNode ( "r0", cls=LinuxRouter, ip="??") # IP address r0-eth0

        # Add Host
        h0 = self.addHost('h0', ip='??', defaultRoute="??")
        h1 = self.addHost('h1', ip='??', defaultRoute="??")
        h2 = self.addHost('h2', ip='??', defaultRoute="??")
        h3 = self.addHost('h3', ip='??', defaultRoute="??")

        # Add Link
        self.addLink( h0, router, intfName2='r0-eth0', bw=10)
        self.addLink( h1, router, intfName2='r0-eth1', bw=10)
        self.addLink( h2, router, intfName2='r0-eth2', bw=10, use_htb=true)
        self.addLink( h3, router, intfName2='r0-eth3', bw=10)

def testIperf( net, server='h0', clients=('h1', 'h2', 'h3')):
    popens = {}
    tperf = 20
    tout = ( tperf + 1 ) * 4
    stopPerf = time() + tout + 5
    inv = 4

    popens[ net[ server ]] = net[ server ].popen( 'iperf -s -t'+str( tout ))
    for client in clients:
        popens[ net[ client ] ] = net[ client ].popen('iperf -c'+net[ server ].IP()+' -i'
                                                        +str(inv)+' -t '+str( tperf) )
    logserver = logclient1 = logclient2 = logclient3 = ""
    for host, line in pmonitor(popens, timeoutms=(tperf + tout)*4):
        if host:
            if host.name == server: logserver += (host.name +": "+line)
            elif host.name == clients[0]: logclient1 += (host.name +": "+line)
            elif host.name == clients[1]: logclient2 += (host.name +": "+line)
            elif host.name == clients[2]: logclient3 += (host.name +": "+line)
        if time () >= stopPerf:
            for p in popens.values():p.send_signal(SIGINT)
    print(logserver)
    print(logclient1)
    print(logclient2)
    print(logclient3)

def runQueue():
    net = Mininet( topo=NetworkTopo(), link=TCLink )
    net.start()

    # Test Ping All host
    info("\n\n", net.ping() ,"\n")

    # Set Queue Discipline to CBQ Bounded
    info( '\n*** Queue Discipline = CBQ [bounded] :\n')
    net[ 'r0' ].cmdPrint( 'tc qdisc del dev r0-eth0 root' )
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth0 root handle 1: cbq rate 7Mbit avpkt 1000')
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth0 parent 1: classid 1:1 cbq rate 1Mbit avpkt 1000 bounded')
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth0 parent 1: classid 1:2 cbq rate 3Mbit avpkt 1000 bounded')
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth0 parent 1: classid 1:3 cbq rate 5Mbit avpkt 1000 bounded')
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth0 parent 1: protocol ip u32 match ip src '+net[ 'h1' ].IP()+' flowid 1:1')
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth0 parent 1: protocol ip u32 match ip src '+net[ 'h2' ].IP()+' flowid 1:2')
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth0 parent 1: protocol ip u32 match ip src '+net[ 'h3' ].IP()+' flowid 1:3')
    net[ 'r0' ].cmdPrint( 'tc qdisc show dev r0-eth0')
    info( "\n")

    #Test Iperf CBQ bounded
    testIperf(net, 'h0', ('h1', 'h2', 'h3') )

    # Set Queue Discipline to CBQ Isolated
    info( '\n*** Queue Discipline = CBQ [isolated] :\n')
    net[ 'r0' ].cmdPrint( 'tc qdisc del dev r0-eth1 root' )
    net[ 'r0' ].cmdPrint(' tc qdisc add dev r0-eth1 root handle 2: cbq rate 7Mbit avpkt 1000' )
    net[ 'r0' ].cmdPrint(' tc qdisc add dev r0-eth1 parent 2: classid 2:1 cbq rate 1Mbit avpkt 1000 isolated' )
    net[ 'r0' ].cmdPrint(' tc qdisc add dev r0-eth1 parent 2: classid 2:2 cbq rate 3Mbit avpkt 1000 isolated' )
    net[ 'r0' ].cmdPrint(' tc qdisc add dev r0-eth1 parent 2: classid 2:3 cbq rate 5Mbit avpkt 1000 isolated' )
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth1 parent 2: protocol ip u32 match ip src '+net[ 'h0' ].IP()+' flowid 2:1' )
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth1 parent 2: protocol ip u32 match ip src '+net[ 'h2' ].IP()+' flowid 2:2' )
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth1 parent 2: protocol ip u32 match ip src '+net[ 'h3' ].IP()+' flowid 2:3' )
    net[ 'r0' ].cmdPrint( 'tc qdisc show dev r0-eth1' )
    info( "\n" )

    # Test Iperf CBQ Isolated
    testIperf(net, 'h1', ('h0', 'h2', 'h3') )

    # Set Queue Discipline to HTB
    info( '\n*** Queue Discipline = HTB :\n')
    net[ 'r0' ].cmdPrint( 'tc qdisc del dev r0-eth2 root' )
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth2 root handle 3:0 htb ' )
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth2 parent 3: classid 3:1 htb rate 5Mbit ceil 4Mbit burst 2k' )
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth2 parent 3: classid 3:2 htb rate 4Mbit ceil 2Mbit burst 2k' )
    net[ 'r0' ].cmdPrint( 'tc qdisc add dev r0-eth2 parent 3: classid 3:3 htb rate 2Mbit ceil 3Mbit burst 2k' )
    net[ 'r0' ].cmdPrint( ' tc qdisc add dev r0-eth2 parent 3:1 handle 31 pfifo limit 10')
    net[ 'r0' ].cmdPrint( ' tc qdisc add dev r0-eth2 parent 3:2 handle 32 pfifo limit 10')
    net[ 'r0' ].cmdPrint( ' tc qdisc add dev r0-eth2 parent 3:3 handle 33 pfifo limit 10')
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth2 parent 3: protocol ip u32 match ip src '+net[ 'h0' ].IP()+' flowid 3:1' )
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth2 parent 3: protocol ip u32 match ip src '+net[ 'h2' ].IP()+' flowid 3:2' )
    net[ 'r0' ].cmdPrint( 'tc filter add dev r0-eth2 parent 3: protocol ip u32 match ip src '+net[ 'h3' ].IP()+' flowid 3:3' )
    net[ 'r0' ].cmdPrint( 'tc qdisc show dev r0-eth2' )
    info( "\n" )

    #Test Iperf HTB
    testIperf( net, 'h1', ('h0', 'h2', 'h3') )

    #Set Queue Discipline to No Queue
    testIperf( net, 'h3', ('h0', 'h1', 'h2') )

    #Stop Mininet
    net.stop()

if __name__ == '__main__':
    os.system( 'mn -c' )
    setLogLevel ( 'info' )
    runQueue()
